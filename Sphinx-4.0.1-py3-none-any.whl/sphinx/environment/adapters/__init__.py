"""
    sphinx.environment.adapters
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~

    Sphinx environment adapters

    :copyright: Copyright 2007-2021 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""
